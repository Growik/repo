import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qsl, urlencode, quote_plus
import requests
import time
import json
import xml.etree.ElementTree as ET
import os
import xbmcvfs
import base64
import tempfile
import glob
from datetime import datetime
import traceback

_addon = xbmcaddon.Addon()
_handle = int(sys.argv[1])
_url = sys.argv[0]

# Configuration
API_URL = "http://192.168.0.220/kodi-api/api.php"
STREAM_SEARCH_API_URL = "http://192.168.0.220/kodi-api/stream_search.php"
MEDIA_SEARCH_API_URL = "http://192.168.0.220/kodi-api/media_search.php"
ITEMS_PER_PAGE = 100
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
WEBSHARE_API_URL = "https://webshare.cz/api/file_link/"
WEBSHARE_WST = "OAwpganmUoDL4P1r"
STREAM_SEARCH_TIMEOUT = 120

# Global flag to prevent duplicate playback
playback_initiated = False

def get_recent_searches_file():
    addon_data = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
    if not os.path.exists(addon_data):
        os.makedirs(addon_data)
    return os.path.join(addon_data, 'recent_searches.json')

def load_recent_searches():
    file_path = get_recent_searches_file()
    try:
        if os.path.exists(file_path):
            with open(file_path, 'r') as f:
                return json.load(f)
    except Exception as e:
        log(f"Error loading recent searches: {str(e)}", xbmc.LOGERROR)
    return []

def save_recent_searches(searches):
    file_path = get_recent_searches_file()
    try:
        with open(file_path, 'w') as f:
            json.dump(searches[:20], f)  # Keep only last 20 searches
    except Exception as e:
        log(f"Error saving recent searches: {str(e)}", xbmc.LOGERROR)

def add_recent_search(query):
    searches = load_recent_searches()
    searches = [s for s in searches if s.lower() != query.lower()]
    searches.insert(0, query)
    save_recent_searches(searches)

def get_url(**kwargs):
    return f"{_url}?{urlencode(kwargs)}"

def log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[{_addon.getAddonInfo('id')}] {msg}", level)

def get_torrent_storage_path():
    addon_data = xbmcvfs.translatePath(_addon.getAddonInfo('profile'))
    torrent_dir = os.path.join(addon_data, 'torrents')
    if not os.path.exists(torrent_dir):
        os.makedirs(torrent_dir)
    return torrent_dir

def limit_torrent_files(max_files=1000):
    torrent_dir = get_torrent_storage_path()
    torrent_files = glob.glob(os.path.join(torrent_dir, '*.torrent'))
    if len(torrent_files) > max_files:
        torrent_files.sort(key=os.path.getmtime)  # Oldest first
        for old_file in torrent_files[:len(torrent_files) - max_files]:
            try:
                os.remove(old_file)
                log(f"Removed old torrent file: {old_file}", xbmc.LOGDEBUG)
            except Exception as e:
                log(f"Failed to remove old torrent file {old_file}: {str(e)}", xbmc.LOGWARNING)

def fetch_webshare_link(ident):
    try:
        payload = {"ident": ident, "wst": WEBSHARE_WST}
        headers = {
            "User-Agent": USER_AGENT,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            "Origin": "https://webshare.cz",
            "Referer": "https://webshare.cz/"
        }
        log(f"Fetching Webshare link for ident: {ident}")
        response = requests.post(WEBSHARE_API_URL, data=payload, headers=headers, timeout=10)
        if response.status_code == 200:
            root = ET.fromstring(response.text)
            status = root.find("status").text
            if status == "OK":
                link = root.find("link").text
                if link:
                    log(f"Webshare playback URL: {link}")
                    return link
                else:
                    log("No link found in Webshare response", xbmc.LOGERROR)
                    return None
            else:
                log(f"Webshare API error: Status {status}", xbmc.LOGERROR)
                return None
        else:
            log(f"Webshare API error: Status {response.status_code}, {response.text}", xbmc.LOGERROR)
            return None
    except ET.ParseError as e:
        log(f"Error parsing Webshare XML response: {str(e)}", xbmc.LOGERROR)
        return None
    except Exception as e:
        log(f"Error fetching Webshare link: {str(e)}", xbmc.LOGERROR)
        return None

def fetch_media(action, page=1, media_type='movie', genre=None, year=None):
    try:
        params = {'action': action, 'page': page, 'limit': ITEMS_PER_PAGE}
        if genre:
            params['genre'] = genre
        if year:
            params['year'] = year
        url = f"{API_URL}?{urlencode(params)}"
        log(f"Fetching URL: {url}")
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            data = response.json()
            return {
                'results': data.get('results', []),
                'total_pages': data.get('pagination', {}).get('total_pages', 1),
                'current_page': page
            }
    except Exception as e:
        log(f"Error fetching {media_type} {action}: {str(e)}", xbmc.LOGERROR)
    return {'results': [], 'total_pages': 1, 'current_page': 1}

def fetch_streams(movie_id=None, episode_id=None):
    try:
        params = {'action': 'get_streams'}
        if movie_id:
            params['movie_id'] = movie_id
        if episode_id:
            params['episode_id'] = episode_id
        url = f"{API_URL}?{urlencode(params)}"
        log(f"Fetching streams URL: {url}")
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            streams = response.json().get('streams', [])
            return {'streams': streams, 'has_streams': len(streams) > 0}
    except Exception as e:
        log(f"Error fetching streams: {str(e)}", xbmc.LOGERROR)
    return {'streams': [], 'has_streams': False}

def search_streams(movie_id=None, episode_id=None, title=None, year=None):
    try:
        params = {'action': 'search_streams'}
        if movie_id:
            params['movie_id'] = movie_id
        if episode_id:
            params['episode_id'] = episode_id
        if title:
            params['movie_name'] = title
        if year:
            params['year'] = str(year)
        log(f"Building stream search with params: movie_id={movie_id}, episode_id={episode_id}, title={title}, year={year}", xbmc.LOGDEBUG)
        url = f"{STREAM_SEARCH_API_URL}?{urlencode(params)}"
        log(f"Searching streams URL: {url}")
        response = requests.get(url, timeout=STREAM_SEARCH_TIMEOUT)
        log(f"Stream search HTTP status: {response.status_code}", xbmc.LOGDEBUG)
        if response.status_code == 200:
            try:
                data = response.json()
                log(f"Stream search response: {data}", xbmc.LOGDEBUG)
                if data.get('success'):
                    inserted = data.get('inserted', 0)
                    streams = data.get('streams', [])
                    log(f"Stream search completed: {inserted} streams inserted, {len(streams)} streams returned", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification('Stream Search', f'Search completed: {inserted} streams found', xbmcgui.NOTIFICATION_INFO, 2000)
                    return True
                elif 'error' in data:
                    error_msg = data.get('error', 'Unknown error')
                    log(f"Stream search completed with no new streams: {error_msg}", xbmc.LOGINFO)
                    xbmcgui.Dialog().notification('Stream Search', error_msg, xbmcgui.NOTIFICATION_INFO, 2000)
                    return True
                else:
                    log(f"Stream search failed with unexpected response: {data}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification('Stream Search Failed', 'Unexpected response from server', xbmcgui.NOTIFICATION_ERROR, 3000)
                    return False
            except ValueError as e:
                log(f"Failed to parse JSON response: {response.text}, error: {str(e)}", xbmc.LOGERROR)
                xbmcgui.Dialog().notification('Stream Search Failed', 'Invalid response from server', xbmcgui.NOTIFICATION_ERROR, 3000)
                return False
        else:
            log(f"Stream search HTTP error: {response.status_code}, response: {response.text}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Stream Search Failed', f'HTTP error: {response.status_code}', xbmcgui.NOTIFICATION_ERROR, 3000)
            return False
    except requests.exceptions.Timeout:
        log("Stream search timed out after 120 seconds", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Stream Search Timeout', 'Search took too long', xbmcgui.NOTIFICATION_ERROR, 3000)
        return False
    except Exception as e:
        log(f"Error searching streams: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Stream Search Failed', f"Error: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 3000)
        return False

def fetch_genres(media_type='movie'):
    try:
        action = 'get_genres' if media_type == 'movie' else 'get_genres_series'
        url = f"{API_URL}?action={action}"
        log(f"Fetching genres URL: {url}")
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.json().get('genres', [])
    except Exception as e:
        log(f"Error fetching genres for {media_type}: {str(e)}", xbmc.LOGERROR)
    return []

def search_media():
    keyboard = xbmc.Keyboard('', 'Search Movies and Series')
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if query:
            add_recent_search(query)
            list_search_results(query, 'all')
            xbmcgui.Dialog().notification('Search', f'Searching for: {query}', xbmcgui.NOTIFICATION_INFO, 2000)
        else:
            log("Search cancelled or empty query", xbmc.LOGINFO)

def fetch_seasons(series_id):
    try:
        url = f"{API_URL}?action=get_seasons&series_id={series_id}"
        log(f"Fetching seasons URL: {url}")
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.json().get('seasons', [])
    except Exception as e:
        log(f"Error fetching seasons: {str(e)}", xbmc.LOGERROR)
    return []

def fetch_episodes(season_id):
    try:
        url = f"{API_URL}?action=get_episodes&season_id={season_id}"
        log(f"Fetching episodes URL: {url}")
        response = requests.get(url, timeout=10)
        if response.status_code == 200:
            return response.json().get('episodes', [])
    except Exception as e:
        log(f"Error fetching episodes: {str(e)}", xbmc.LOGERROR)
    return []

def show_main_menu():
    menu_items = [
        ('Search', 'search', True),
        ('Recent Searches', 'recent_searches', True),
        ('Movies', 'movies_menu', True),
        ('Series', 'series_menu', True),
        ('Sktorrent Latest', 'sktorrent_latest', True)
    ]
    for label, action, is_folder in menu_items:
        li = xbmcgui.ListItem(label=label)
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def show_sub_menu(media_type):
    action_prefix = '' if media_type == 'movie' else '_series'
    menu_items = [
        ('Recently Added', f'recent{action_prefix}', True),
        ('Trending', f'trending{action_prefix}', True),
        ('Random', f'random{action_prefix}', True),
        ('Year', f'year_{media_type}', True),
        ('Genre', f'genre_{media_type}', True),
        ('CZ Dabing', f'cz_dabing{action_prefix}', True),
        ('CZ Subtitles', f'cz_subtitles{action_prefix}', True)
    ]
    for label, action, is_folder in menu_items:
        li = xbmcgui.ListItem(label=label)
        url = get_url(action=action)
        xbmcplugin.addDirectoryItem(_handle, url, li, is_folder)
    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def list_years(media_type):
    current_year = datetime.now().year
    years = list(range(1980, current_year + 1))[::-1]
    for year in years:
        li = xbmcgui.ListItem(label=str(year))
        action = 'by_year' if media_type == 'movie' else 'by_year_series'
        url = get_url(action=action, year=str(year))
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    xbmcplugin.setContent(_handle, 'menu')
    xbmcplugin.endOfDirectory(_handle)

def list_media(action, page=1, media_type='movie', genre=None, year=None):
    data = fetch_media(action, page, media_type, genre, year)
    items = data.get('results', [])
    current_page = data.get('current_page', 1)
    total_pages = data.get('total_pages', 1)

    if current_page > 1:
        add_nav_item("<< Previous Page", action, current_page-1, genre, year)
    if current_page < total_pages:
        add_nav_item("Next Page >>", action, current_page+1, genre, year)

    for item in items:
        title = item.get('title_cz', '') or item.get('title', 'Unknown')
        plot = item.get('overview_cz', '') or item.get('overview', '')
        year_item = item.get('year')
        log(f"Listing media: title={title}, year={year_item}, media_type={media_type}", xbmc.LOGDEBUG)
        
        plot = f"{plot}\nYear: {year_item}"
        if item.get('rating') is not None:
            plot = f"{plot}\nRating: {item['rating']}%"

        li = xbmcgui.ListItem(label=title)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType(media_type)
        info_tag.setTitle(title)
        if year_item:
            info_tag.setYear(int(year_item))
        info_tag.setPlot(plot)
        
        li.setArt({
            'poster': item.get('poster_url', ''),
            'fanart': item.get('backdrop_url', _addon.getAddonInfo('fanart'))
        })
        li.setProperty('IsPlayable', 'false')
        context_items = []
        if media_type == 'movie':
            context_items.append(('Select Stream', f'RunPlugin({get_url(action="show_streams", movie_id=item["id"], title=title, year=year_item)})'))
            context_items.append(('Search for Stream', f'RunPlugin({get_url(action="search_stream", movie_id=item["id"], title=title, year=year_item)})'))
            url = get_url(action='show_streams', movie_id=item['id'], title=title, year=year_item)
        else:
            context_items.append(('Show Seasons', f'RunPlugin({get_url(action="show_seasons", series_id=item["id"], title=title)})'))
            url = get_url(action='show_seasons', series_id=item['id'], title=title)
        li.addContextMenuItems(context_items)
        xbmcplugin.addDirectoryItem(_handle, url, li, True)

    if current_page > 1:
        add_nav_item("Previous Page", action, current_page-1, genre, year)
    if current_page < total_pages:
        add_nav_item("Next Page", action, current_page+1, genre, year)

    xbmcplugin.setContent(_handle, 'tvshows' if media_type == 'series' else 'movies')
    xbmcplugin.endOfDirectory(_handle)

def list_genres(media_type='movie'):
    genres = fetch_genres(media_type)
    if not genres:
        log(f"No genres available for {media_type}", xbmc.LOGINFO)
        xbmcgui.Dialog().ok('Info', f'No genres found for {media_type}.')
        xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    
    for genre in genres:
        li = xbmcgui.ListItem(label=genre)
        action = 'by_genre' if media_type == 'movie' else 'by_genre_series'
        url = get_url(action=action, genre=genre)
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    
    xbmcplugin.setContent(_handle, 'menu')
    xbmcplugin.endOfDirectory(_handle)

def list_sktorrent_latest(page=1):
    data = fetch_media('sktorrent_latest', page, 'movie')
    items = data.get('results', [])
    current_page = data.get('pagination', {}).get('page', 1)
    total_pages = data.get('pagination', {}).get('total_pages', 1)

    if current_page > 1:
        add_nav_item("Previous Page", 'sktorrent_latest', current_page-1)
    if current_page < total_pages:
        add_nav_item("Next Page", 'sktorrent_latest', current_page+1)

    for item in items:
        title = item.get('title', 'Unknown')
        plot = f"Genre: {item.get('genre', 'N/A')}\nRating: {item.get('rating', 'N/A')}%"
        
        li = xbmcgui.ListItem(label=title)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('movie')
        info_tag.setTitle(title)
        info_tag.setPlot(plot)
        
        li.setArt({
            'poster': item.get('poster_url', ''),
            'fanart': item.get('poster_url', _addon.getAddonInfo('fanart'))
        })
        li.setProperty('IsPlayable', 'false')  # Avoid playlist
        
        play_url = get_url(action='play_sktorrent', torrent_url=item['link'])
        log(f"Adding item with play URL: {play_url}", xbmc.LOGDEBUG)
        xbmcplugin.addDirectoryItem(_handle, play_url, li, False)

    if current_page > 1:
        add_nav_item("Previous Page", 'sktorrent_latest', current_page-1)
    if current_page < total_pages:
        add_nav_item("Next Page", 'sktorrent_latest', current_page+1)

    xbmcplugin.setContent(_handle, 'movies')
    xbmcplugin.endOfDirectory(_handle)

def list_seasons(series_id, series_title):
    seasons = fetch_seasons(series_id)
    if not seasons:
        log(f"No seasons available for series: {series_title} (ID: {series_id})", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', 'No seasons available')
        xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    
    for season in seasons:
        title = season.get('title', f"Season {season['season_number']}")
        li = xbmcgui.ListItem(label=title)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('season')
        info_tag.setTitle(title)
        info_tag.setPlot(season.get('overview', ''))
        
        li.setArt({
            'poster': season.get('poster_url', ''),
            'fanart': _addon.getAddonInfo('fanart')
        })
        li.setProperty('IsPlayable', 'false')
        url = get_url(action='show_episodes', season_id=season['id'], series_title=series_title)
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    
    xbmcplugin.setContent(_handle, 'seasons')
    xbmcplugin.endOfDirectory(_handle)

def list_episodes(season_id, series_title):
    episodes = fetch_episodes(season_id)
    if not episodes:
        log(f"No episodes available for season ID: {season_id}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Error', 'No episodes available')
        xbmcplugin.endOfDirectory(_handle, succeeded=False)
        return
    
    for episode in episodes:
        title = episode.get('title', f"Episode {episode['episode_number']}")
        display_title = f"S{episode.get('season_number', 0):02d}E{episode['episode_number']:02d} - {title}"
        plot = episode.get('overview', '')
        if episode.get('rating') is not None:
            plot = f"{plot}\nRating: {episode['rating']}%"
        
        li = xbmcgui.ListItem(label=display_title)
        info_tag = li.getVideoInfoTag()
        info_tag.setMediaType('episode')
        info_tag.setTitle(title)
        info_tag.setPlot(plot)
        info_tag.setEpisode(episode['episode_number'])
        info_tag.setSeason(episode.get('season_number', 0))
        info_tag.setFirstAired(episode.get('air_date', ''))
        
        li.setArt({
            'poster': _addon.getAddonInfo('icon'),
            'fanart': _addon.getAddonInfo('fanart')
        })
        li.setProperty('IsPlayable', 'false')
        context_items = [
            ('Select Stream', f'RunPlugin({get_url(action="show_streams", episode_id=episode["id"], title=display_title)})'),
            ('Search for Stream', f'RunPlugin({get_url(action="search_stream", episode_id=episode["id"], title=display_title)})')
        ]
        li.addContextMenuItems(context_items)
        url = get_url(action='show_streams', episode_id=episode['id'], title=display_title)
        xbmcplugin.addDirectoryItem(_handle, url, li, True)
    
    xbmcplugin.setContent(_handle, 'episodes')
    xbmcplugin.endOfDirectory(_handle)

def add_nav_item(label, action, page, genre=None, year=None):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': _addon.getAddonInfo('icon')})
    params = {'action': action, 'page': page}
    if genre:
        params['genre'] = genre
    if year:
        params['year'] = year
    url = get_url(**params)
    xbmcplugin.addDirectoryItem(_handle, url, li, True)

def show_recent_searches():
    searches = load_recent_searches()
    if not searches:
        xbmcgui.Dialog().ok('Info', 'No recent searches')
        return
    
    dialog = xbmcgui.Dialog()
    selected = dialog.select('Recent Searches', searches)
    
    if selected >= 0:
        query = searches[selected]
        list_search_results(query, 'all')

def show_streams_dialog(movie_id=None, episode_id=None, title=None, year=None):
    log(f"Opening streams dialog: movie_id={movie_id}, episode_id={episode_id}, title={title}, year={year}", xbmc.LOGDEBUG)
    while True:
        streams = fetch_streams(movie_id, episode_id)['streams']
        log(f"Fetched streams for {'movie_id' if movie_id else 'episode_id'}: {movie_id or episode_id}: {len(streams)} streams found")

        stream_labels = []
        stream_data = []

        stream_labels.append("[COLOR yellow][Search for Streams][/COLOR]")
        stream_data.append({'action': 'search'})

        if streams:
            for stream in streams:
                label_parts = [stream.get('quality', 'Unknown')]
                if stream.get('size'):
                    label_parts.append(f"({stream['size']})")
                if stream.get('language'):
                    label_parts.append(f"[{stream['language']}]")
                if stream.get('subtitles') and 'czech' in stream['subtitles'].lower():
                    label_parts.append("Tit: (CZ)")
                if stream.get('stream_type') == 'torrent':
                    label_parts.append("[Torrent]")
                if stream.get('source') == 'sktorrent':
                    if stream.get('stream_type') == 'torrent':
                        label_parts.append("[SkTorrent]")
                    else:
                        label_parts.append("[Sktorrent Direct]")
                elif stream.get('source') == 'webshare':
                    label_parts.append("[Webshare]")
                stream_labels.append(" ".join(label_parts))
                stream_data.append({
                    'action': 'play',
                    'stream_type': stream['stream_type'],
                    'url': stream['url'],
                    'subtitles': stream.get('subtitles')
                })
                log(f"Stream label: {stream_labels[-1]}, Type: {stream['stream_type']}, URL: {stream['url']}")
        else:
            stream_labels.append("No streams available")
            stream_data.append({'action': 'none'})

        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(100)
        dialog = xbmcgui.Dialog()
        selected = dialog.select(f"Select Stream for {title}", stream_labels)

        if selected < 0:
            log("Stream selection cancelled", xbmc.LOGINFO)
            xbmc.executebuiltin('Dialog.Close(all,true)')
            break

        selected_item = stream_data[selected]
        if selected_item['action'] == 'search':
            if search_streams(movie_id, episode_id, title, year):
                continue
            else:
                xbmc.executebuiltin('Dialog.Close(all,true)')
                break
        elif selected_item['action'] == 'play':
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.sleep(100)
            if selected_item['stream_type'] == 'direct':
                play_stream(selected_item['url'], title, selected_item.get('subtitles'))
            elif selected_item['stream_type'] == 'webshare':
                playback_url = fetch_webshare_link(selected_item['url'])
                if playback_url:
                    play_stream(playback_url, title, selected_item.get('subtitles'))
                else:
                    log(f"Failed to get Webshare playback URL for ident: {selected_item['url']}", xbmc.LOGERROR)
                    xbmcgui.Dialog().notification('Playback Failed', 'Unable to fetch Webshare stream URL', xbmcgui.NOTIFICATION_ERROR, 3000)
            else:
                play_torrent(selected_item['url'])
            break
        else:
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmcgui.Dialog().ok('Error', 'No streams available for this media')
            break

def play_stream(url, title, subtitles=None):
    log(f"Attempting to play direct stream: {url} for {title}")
    li = xbmcgui.ListItem(label=title)
    li.setPath(url)
    li.setProperty('IsPlayable', 'true')
    
    info_tag = li.getVideoInfoTag()
    info_tag.setMediaType('episode' if 'S' in title else 'movie')
    info_tag.setTitle(title)
    
    if subtitles:
        log(f"Setting subtitles: {subtitles}")
        li.setSubtitles([subtitles])
    
    li.setProperty('inputstreamaddon', 'inputstream.adaptive')
    li.setProperty('inputstream.adaptive.stream_headers', f"User-Agent={quote_plus(USER_AGENT)}")
    
    try:
        xbmc.Player().play(url, li)
        log("xbmc.Player called for direct stream")
        xbmc.sleep(1000)
        if xbmc.getCondVisibility('Player.HasMedia'):
            log("Playback initiated successfully")
        else:
            log("Playback failed to start", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Playback Failed', 'Unable to start playback. Check URL or server.', xbmcgui.NOTIFICATION_ERROR, 3000)
    except Exception as e:
        log(f"Error initiating playback: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Failed', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)

def play_sktorrent_torrent(torrent_url):
    global playback_initiated
    if playback_initiated:
        log("Playback already initiated, skipping duplicate attempt", xbmc.LOGDEBUG)
        return

    try:
        log(f"Starting torrent playback for URL: {torrent_url}", xbmc.LOGINFO)
        playback_initiated = True

        api_url = f"{API_URL}?action=sktorrent_torrent&url={quote_plus(torrent_url)}"
        log(f"Calling API: {api_url}", xbmc.LOGDEBUG)

        start_time = time.time()
        response = requests.get(api_url, timeout=30)
        log(f"API request completed in {time.time() - start_time:.1f} seconds, status: {response.status_code}", xbmc.LOGDEBUG)

        if response.status_code != 200:
            raise Exception(f"API request failed with status {response.status_code}")

        data = response.json()
        if not data.get('success'):
            raise Exception(data.get('error', 'Failed to fetch torrent'))

        base64_torrent = data.get('torrent', '')
        if not base64_torrent:
            raise Exception("No torrent data received from API")
        
        log(f"Received torrent data: {len(base64_torrent)} bytes (base64)", xbmc.LOGDEBUG)
        
        # Close dialogs
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(100)
        log("Dialogs closed before play_torrent", xbmc.LOGDEBUG)
        
        play_torrent(base64_torrent)
        
        # Monitor playback
        timeout = 60  # Extended timeout
        start_time = time.time()
        while time.time() - start_time < timeout:
            if xbmc.getCondVisibility('Player.HasMedia'):
                log("Playback confirmed active", xbmc.LOGINFO)
                return
            xbmc.sleep(500)
        
        log("Playback did not start within 60 seconds", xbmc.LOGWARNING)
        xbmcgui.Dialog().notification('Warning', 'Playback may have failed to start', xbmcgui.NOTIFICATION_WARNING, 3000)
        
    except Exception as e:
        log(f"Error playing torrent: {str(e)}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Error', f"Playback failed: {str(e)}", xbmcgui.NOTIFICATION_ERROR, 3000)
    finally:
        playback_initiated = False
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.sleep(100)
        log("Playback initiation reset", xbmc.LOGDEBUG)

def play_torrent(base64_torrent):
    if not xbmc.getCondVisibility('System.HasAddon(plugin.video.elementum)'):
        log("Elementum addon not installed", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Error', 'Elementum addon required for torrent playback', xbmcgui.NOTIFICATION_ERROR, 3000)
        return

    try:
        # Decode base64 torrent data
        log("Decoding base64 torrent data", xbmc.LOGDEBUG)
        torrent_data = base64.b64decode(base64_torrent.strip())
        if not torrent_data.startswith(b'd8:announce'):
            log("Invalid torrent data: does not start with bencode signature", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Torrent Playback Failed', 'Invalid torrent data', xbmcgui.NOTIFICATION_ERROR, 3000)
            return

        # Create temporary .torrent file
        temp_fd, temp_path = tempfile.mkstemp(suffix='.torrent')
        try:
            with os.fdopen(temp_fd, 'wb') as temp_file:
                temp_file.write(torrent_data)
            log(f"Temporary .torrent file created at: {temp_path}", xbmc.LOGDEBUG)

            # Extract filename from torrent data
            filename = None
            name_start = torrent_data.find(b'4:name')
            if name_start != -1:
                length_start = name_start + 6
                colon_pos = torrent_data.find(b':', length_start)
                if colon_pos != -1:
                    length = int(torrent_data[length_start:colon_pos])
                    filename = torrent_data[colon_pos + 1:colon_pos + 1 + length].decode('utf-8', errors='ignore')
                    log(f"Extracted filename: {filename}", xbmc.LOGINFO)
            else:
                filename = "Unknown"
                log("Could not extract filename from torrent data", xbmc.LOGWARNING)

            # Prepare Elementum URL with file path
            encoded_path = quote_plus(temp_path)
            elementum_url = f'plugin://plugin.video.elementum/playuri?uri={encoded_path}'
            log(f"Preparing torrent via Elementum: {elementum_url}", xbmc.LOGINFO)

            # Set up list item for playback
            li = xbmcgui.ListItem(path=elementum_url, label=filename)
            li.setProperty('IsPlayable', 'true')
            li.setContentLookup(False)
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType('movie')  # Adjust for series if needed
            info_tag.setTitle(filename)

            # Try stream URL first
            stream_url = None
            check_url = f'http://127.0.0.1:8080/files/{quote_plus(filename)}' if filename != "Unknown" else None
            if check_url:
                log(f"Stream check URL: {check_url}", xbmc.LOGDEBUG)
                for _ in range(3):  # Retry 3 times
                    try:
                        response = requests.get(check_url, timeout=5, stream=True)
                        if response.status_code == 200:
                            stream_url = check_url
                            log(f"Elementum stream URL found: {stream_url}", xbmc.LOGINFO)
                            break
                    except Exception as e:
                        log(f"Stream check failed: {str(e)}", xbmc.LOGDEBUG)
                    xbmc.sleep(2000)

            if stream_url:
                li.setPath(stream_url)
                xbmc.Player().play(stream_url, li)
                log("Playback initiated with stream URL", xbmc.LOGINFO)
                xbmc.sleep(5000)  # Wait for player to engage
                if xbmc.getCondVisibility('Player.HasMedia'):
                    log("Playback started successfully via stream URL", xbmc.LOGINFO)
                    return
                else:
                    log("Stream URL playback failed, falling back to RunPlugin", xbmc.LOGWARNING)

            # Fallback to RunPlugin
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.sleep(100)
            xbmc.executebuiltin(f'RunPlugin({elementum_url})')
            log(f"Executed RunPlugin: {elementum_url}", xbmc.LOGDEBUG)

            # Monitor playback
            timeout = 300  # Extended timeout
            start_time = time.time()
            status_url = 'http://127.0.0.1:8080/torrents'
            while time.time() - start_time < timeout:
                if xbmc.getCondVisibility('Player.HasMedia'):
                    log("Playback started successfully via RunPlugin", xbmc.LOGINFO)
                    return
                if check_url and not stream_url:
                    try:
                        response = requests.get(check_url, timeout=5, stream=True)
                        if response.status_code == 200:
                            stream_url = check_url
                            log(f"Elementum stream URL found: {stream_url}", xbmc.LOGINFO)
                            li.setPath(stream_url)
                            xbmc.Player().play(stream_url, li)
                            xbmc.sleep(5000)
                            if xbmc.getCondVisibility('Player.HasMedia'):
                                log("Playback started successfully via late stream URL", xbmc.LOGINFO)
                                return
                    except Exception as e:
                        log(f"Stream check failed: {str(e)}", xbmc.LOGDEBUG)
                try:
                    status_response = requests.get(status_url, timeout=2)
                    if status_response.status_code == 200:
                        torrents = status_response.json()
                        for torrent in torrents:
                            if torrent.get('name') == filename:
                                log(f"Torrent status: {torrent.get('status', 'N/A')}, progress: {torrent.get('progress', 0)}%, peers: {torrent.get('peers', 0)}, speed: {torrent.get('download_speed', 0) / 1024:.2f} MB/s", xbmc.LOGDEBUG)
                except Exception as e:
                    log(f"Status check failed: {str(e)}", xbmc.LOGDEBUG)
                xbmc.sleep(1000)

            log("Failed to start playback within 300 seconds", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', 'No stream URL provided by Elementum or playback timed out', xbmcgui.NOTIFICATION_ERROR, 3000)

        finally:
            # Clean up temporary file
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                    log(f"Temporary file removed: {temp_path}", xbmc.LOGDEBUG)
                except Exception as e:
                    log(f"Failed to remove temporary file: {str(e)}", xbmc.LOGWARNING)

    except Exception as e:
        log(f"Torrent playback error: {str(e)}\n{traceback.format_exc()}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Error', f'Torrent playback failed: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 3000)
        return

def list_search_results(query, media_type='all', page=1):
    try:
        url = f"{API_URL}?action=search&query={quote_plus(query)}&type={media_type}&page={page}&limit={ITEMS_PER_PAGE}"
        log(f"Search URL: {url}")
        response = requests.get(url, timeout=10)
        log(f"Search response: {response.text[:200]}...")
        if response.status_code == 200:
            data = response.json()
            items = data.get('results', [])
            current_page = data.get('pagination', {}).get('page', 1)
            total_pages = data.get('pagination', {}).get('total_pages', 1)
            
            if not items:
                log(f"No search results for query: {query}, type: {media_type}", xbmc.LOGINFO)
                xbmcgui.Dialog().ok('Search', 'No results found.')
                xbmcplugin.endOfDirectory(_handle, succeeded=False)
                return
            
            if current_page > 1:
                add_nav_item("Previous Page", f"search_{media_type}", current_page-1)
            if current_page < total_pages:
                add_nav_item("Next Page", f"search_{media_type}", current_page+1)
            
            for item in items:
                title = item.get('title_cz', '') or item.get('title', 'Unknown')
                plot = item.get('overview_cz', '') or item.get('overview', '')
                year = item.get('year')
                log(f"Listing search result: title={title}, year={year}, media_type={item['media_type']}", xbmc.LOGDEBUG)
                
                if item.get('rating') is not None:
                    plot = f"{plot}\nRating: {item['rating']}%"
                
                li = xbmcgui.ListItem(label=title)
                info_tag = li.getVideoInfoTag()
                info_tag.setMediaType(item['media_type'])
                info_tag.setTitle(title)
                if year:
                    info_tag.setYear(int(year))
                info_tag.setPlot(plot)
                
                li.setArt({
                    'poster': item.get('poster_url', ''),
                    'fanart': item.get('backdrop_url', _addon.getAddonInfo('fanart'))
                })
                li.setProperty('IsPlayable', 'false')
                context_items = []
                if item['media_type'] == 'movie':
                    context_items.append(('Select Stream', f'RunPlugin({get_url(action="show_streams", movie_id=item["id"], title=title, year=year)})'))
                    context_items.append(('Search for Stream', f'RunPlugin({get_url(action="search_stream", movie_id=item["id"], title=title, year=year)})'))
                    url = get_url(action='show_streams', movie_id=item['id'], title=title, year=year)
                else:
                    context_items.append(('Show Seasons', f'RunPlugin({get_url(action="show_seasons", series_id=item["id"], title=title)})'))
                    url = get_url(action='show_seasons', series_id=item['id'], title=title)
                li.addContextMenuItems(context_items)
                xbmcplugin.addDirectoryItem(_handle, url, li, True)
            
            if current_page > 1:
                add_nav_item("Previous Page", f"search_{media_type}", current_page-1)
            if current_page < total_pages:
                add_nav_item("Next Page", f"search_{media_type}", current_page+1)
            
            xbmcplugin.setContent(_handle, 'movies' if media_type == 'movie' else 'tvshows')
            xbmcplugin.endOfDirectory(_handle)
        else:
            log(f"Search HTTP error: {response.status_code}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Search Failed', f'HTTP error: {response.status_code}', xbmcgui.NOTIFICATION_ERROR, 3000)
            xbmcplugin.endOfDirectory(_handle, succeeded=False)
    except Exception as e:
        log(f"Error searching media: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Search Failed', str(e), xbmcgui.NOTIFICATION_ERROR, 3000)
        xbcplugin.endOfDirectory(_handle, succeeded=False)

def router(params):
    action = params.get('action', 'main')
    page = int(params.get('page', 1))
    
    log(f"Routing action: {action}, params: {params}", xbmc.LOGDEBUG)
    if action == 'main':
        show_main_menu()
    elif action == 'recent_searches':
        show_recent_searches()
    elif action == 'movies_menu':
        show_sub_menu('movie')
    elif action == 'series_menu':
        show_sub_menu('series')
    elif action == 'search':
        search_media()
    elif action == 'sktorrent_latest':
        list_sktorrent_latest(page)
    elif action.startswith('search_'):
        parts = action.split('_')
        media_type = parts[1]
        query = '_'.join(parts[2:]) if len(parts) > 2 else ''
        list_search_results(query, media_type, page)
    elif action == 'recent':
        list_media('recent', page, 'movie')
    elif action == 'recent_series':
        list_media('recent_series', page, 'series')
    elif action == 'trending':
        list_media('trending', page, 'movie')
    elif action == 'trending_series':
        list_media('trending_series', page, 'series')
    elif action == 'random':
        list_media('random', page, 'movie')
    elif action == 'random_series':
        list_media('random_series', page, 'series')
    elif action == 'genre_movie':
        list_genres('movie')
    elif action == 'genre_series':
        list_genres('series')
    elif action == 'year_movie':
        list_years('movie')
    elif action == 'year_series':
        list_years('series')
    elif action == 'by_genre':
        list_media('by_genre', page, 'movie', params.get('genre'))
    elif action == 'by_genre_series':
        list_media('by_genre_series', page, 'series', params.get('genre'))
    elif action == 'by_year':
        list_media('by_year', page, 'movie', year=params.get('year'))
    elif action == 'by_year_series':
        list_media('by_year_series', page, 'series', year=params.get('year'))
    elif action == 'cz_dabing':
        list_media('cz_dabing', page, 'movie')
    elif action == 'cz_dabing_series':
        list_media('cz_dabing_series', page, 'series')
    elif action == 'cz_subtitles':
        list_media('cz_subtitles', page, 'movie')
    elif action == 'cz_subtitles_series':
        list_media('cz_subtitles_series', page, 'series')
    elif action == 'show_seasons':
        list_seasons(params['series_id'], params['title'])
    elif action == 'show_episodes':
        list_episodes(params['season_id'], params['series_title'])
    elif action == 'show_streams':
        show_streams_dialog(params.get('movie_id'), params.get('episode_id'), params.get('title'), params.get('year'))
    elif action == 'search_stream':
        show_streams_dialog(params.get('movie_id'), params.get('episode_id'), params.get('title'), params.get('year'))
    elif action == 'play_torrent':
        play_torrent(params['url'])
    elif action == 'play_sktorrent':
        torrent_url = params.get('torrent_url')
        if torrent_url:
            play_sktorrent_torrent(torrent_url)
        else:
            log("No torrent_url provided for play_sktorrent action", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', 'Missing torrent URL', xbmcgui.NOTIFICATION_ERROR, 3000)
    else:
        log(f"Unknown action: {action}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Error', f'Unknown action: {action}', xbmcgui.NOTIFICATION_ERROR, 3000)
        xbcplugin.endOfDirectory(_handle, succeeded=False)

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    router(params)