import xbmc
import xbmcaddon
import time

class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.addon = xbmcaddon.Addon()
    
    def run(self):
        while not self.abortRequested():
            # Check every 30 seconds if we should exit
            if self.waitForAbort(30):
                break
            # Perform periodic tasks here

if __name__ == '__main__':
    Monitor().run()