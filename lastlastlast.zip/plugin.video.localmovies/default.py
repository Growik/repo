import sys
from resources.lib.core import router

if __name__ == '__main__':
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    router(params)